import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/src/lib/auth";
import OpenAI from "openai";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const movie = session.user.favoriteMovie;
  if (!movie) {
    return NextResponse.json({ error: "No favorite movie set" }, { status: 400 });
  }

  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const prompt = `Give ONE quirky, spoiler-free fun fact about the movie "${movie}". Keep it under 45 words.`;

  try {
    // Try OpenAI first
    const completion = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are a concise movie trivia assistant." },
        { role: "user", content: prompt }
      ],
      temperature: 0.9,
      max_tokens: 90
    });

    const fact = completion.choices[0]?.message?.content?.trim() || "No fact found.";
    return NextResponse.json({ fact });

  } catch (err) {
    console.error("⚠️ OpenAI failed, falling back to Hugging Face:", err.message);

    // Fallback → Hugging Face GPT-2
    try {
      const hfResponse = await fetch(
        "https://api-inference.huggingface.co/models/openai-community/gpt2",
        {
          headers: {
            Authorization: `Bearer ${process.env.HF_API_KEY}`,
            "Content-Type": "application/json",
          },
          method: "POST",
          body: JSON.stringify({
            inputs: prompt,
            parameters: { max_new_tokens: 60 }
          }),
        }
      );

      if (!hfResponse.ok) {
        throw new Error(`Hugging Face API error: ${hfResponse.status}`);
      }

      const hfData = await hfResponse.json();
      const fact =
        hfData[0]?.generated_text?.replace(prompt, "").trim() ||
        "Could not generate a fun fact.";

      return NextResponse.json({ fact });
    } catch (hfErr) {
      console.error("❌ Hugging Face also failed:", hfErr.message);
      return NextResponse.json({ error: "Both providers failed" }, { status: 500 });
    }
  }
}
